"""
core/models.py

Small shared types that multiple modules need but that don't belong to
any single one of them (task.py, state.py, scheduler.py all reference
these). Keeping them here avoids circular imports between those modules.
"""

from __future__ import annotations

from enum import Enum


class Phase(str, Enum):
    """A stage in the pipeline, used by scheduler.py to group tasks that
    can run in parallel vs. tasks that must wait for a prior phase."""
    RESEARCH = "research"
    BUILD = "build"          # database, backend, frontend run in parallel here
    VERIFY = "verify"        # testing, security, performance run in parallel here
    DOCUMENT = "document"
    REVIEW = "review"


# Which agent belongs to which phase. Used by scheduler.py to compute
# phase readiness (a phase is ready once every agent in the prior phase
# has finished all its tasks for the round).
PHASE_AGENTS: dict[Phase, list[str]] = {
    Phase.RESEARCH: ["research"],
    Phase.BUILD: ["database", "backend", "frontend"],
    Phase.VERIFY: ["testing", "security", "performance"],
    Phase.DOCUMENT: ["documentation"],
    Phase.REVIEW: ["reviewer"],
}

PHASE_ORDER: list[Phase] = [
    Phase.RESEARCH, Phase.BUILD, Phase.VERIFY, Phase.DOCUMENT, Phase.REVIEW,
]


class QualityCategory(str, Enum):
    REQUIREMENTS = "requirements"
    CORRECTNESS = "correctness"
    TESTING = "testing"
    PERFORMANCE = "performance"
    SECURITY = "security"
    DOCUMENTATION = "documentation"
    CODE_QUALITY = "code_quality"


# Reviewer's weighted score, per the ForgeAI blueprint.
QUALITY_WEIGHTS: dict[QualityCategory, float] = {
    QualityCategory.REQUIREMENTS: 0.35,
    QualityCategory.CORRECTNESS: 0.20,
    QualityCategory.TESTING: 0.15,
    QualityCategory.PERFORMANCE: 0.10,
    QualityCategory.SECURITY: 0.10,
    QualityCategory.DOCUMENTATION: 0.05,
    QualityCategory.CODE_QUALITY: 0.05,
}

assert abs(sum(QUALITY_WEIGHTS.values()) - 1.0) < 1e-9, "quality weights must sum to 1.0"
