"""
core/scheduler.py

TaskQueue (core/queue.py) already resolves per-task dependencies. Scheduler
adds the coarser-grained phase gating from the blueprint: Research must
fully finish before Build starts; Database/Backend/Frontend run in
parallel within Build; Testing/Security/Performance run in parallel
within Verify; and so on.

Phase membership now comes from the AgentRegistry rather than a static
dict, so an agent the user adds through the TUI (e.g. a "Mobile" agent
assigned to the Build phase) is picked up automatically -- no code
change needed here.
"""

from __future__ import annotations

from core.agent_registry import AgentRegistry
from core.models import PHASE_ORDER, Phase
from core.queue import TaskQueue
from core.task import Task, TaskStatus


class Scheduler:
    def __init__(self, queue: TaskQueue, registry: AgentRegistry) -> None:
        self.queue = queue
        self.registry = registry
        self._phase_index = 0

    @property
    def current_phase(self) -> Phase:
        return PHASE_ORDER[self._phase_index]

    def reset(self) -> None:
        self._phase_index = 0

    def agents_in_phase(self, phase: Phase | None = None) -> list[str]:
        return [d.name for d in self.registry.list_in_phase(phase or self.current_phase)]

    def ready_tasks(self) -> list[Task]:
        """Pending, dependency-satisfied tasks belonging to agents in the current phase."""
        ready: list[Task] = []
        for agent in self.agents_in_phase():
            ready.extend(self.queue.pending_for_agent(agent))
        return ready

    def phase_complete(self) -> bool:
        """True if every task assigned so far to the current phase's agents is DONE or FAILED."""
        agents = set(self.agents_in_phase())
        relevant = [t for t in self.queue.all() if t.agent in agents]
        if not relevant:
            return False  # nothing assigned yet -- not "complete", just empty
        return all(t.status in (TaskStatus.DONE, TaskStatus.FAILED) for t in relevant)

    def advance(self) -> bool:
        """Move to the next phase. Returns False if already at the last phase."""
        if self._phase_index >= len(PHASE_ORDER) - 1:
            return False
        self._phase_index += 1
        return True

    def is_last_phase(self) -> bool:
        return self._phase_index == len(PHASE_ORDER) - 1
