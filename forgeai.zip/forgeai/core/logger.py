"""
core/logger.py

Subscribes to the EventBus and persists every event to disk:
  workspace/logs/combined.log      -- everything, in order
  workspace/logs/<agent>.log       -- per-agent transcript

This is deliberately plain-text/line-based rather than JSON-per-line so it
stays human-readable while tailing during development. A structured
(JSONL) sink can be added later for the memory agent to query.
"""

from __future__ import annotations

import os
import time
from pathlib import Path

from core.events import Event, EventBus


class Logger:
    def __init__(self, bus: EventBus, log_dir: str | Path = "workspace/logs") -> None:
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.combined_path = self.log_dir / "combined.log"
        bus.subscribe(self._on_event)

    def _agent_path(self, agent: str) -> Path:
        safe = agent.replace("/", "_")
        return self.log_dir / f"{safe}.log"

    def _format(self, event: Event) -> str:
        ts = time.strftime("%H:%M:%S", time.localtime(event.timestamp))
        return f"[{ts}] [{event.source:<10}] [{event.type.value:<15}] {event.message}"

    def _on_event(self, event: Event) -> None:
        line = self._format(event) + "\n"
        with self.combined_path.open("a", encoding="utf-8") as f:
            f.write(line)
        with self._agent_path(event.source).open("a", encoding="utf-8") as f:
            f.write(line)

    def tail(self, agent: str | None = None, n: int = 50) -> list[str]:
        path = self._agent_path(agent) if agent else self.combined_path
        if not path.exists():
            return []
        with path.open(encoding="utf-8") as f:
            lines = f.readlines()
        return [l.rstrip("\n") for l in lines[-n:]]
