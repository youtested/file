"""
core/queue.py

TaskQueue holds every task in the system and hands the orchestrator the
next runnable task: PENDING, not blocked by an incomplete dependency,
highest priority first, oldest first as a tiebreak.
"""

from __future__ import annotations

from typing import Optional

from core.task import Task, TaskStatus


class TaskQueue:
    def __init__(self) -> None:
        self._tasks: dict[int, Task] = {}

    def add(self, task: Task) -> Task:
        self._tasks[task.id] = task
        return task

    def get(self, task_id: int) -> Optional[Task]:
        return self._tasks.get(task_id)

    def all(self) -> list[Task]:
        return list(self._tasks.values())

    def _done_ids(self) -> set[int]:
        return {t.id for t in self._tasks.values() if t.status == TaskStatus.DONE}

    def pending_for_agent(self, agent: str) -> list[Task]:
        done = self._done_ids()
        return sorted(
            (
                t for t in self._tasks.values()
                if t.agent == agent
                and t.status == TaskStatus.PENDING
                and t.is_ready(done)
            ),
            key=lambda t: (-t.priority.value, t.created_at),
        )

    def next_for_agent(self, agent: str) -> Optional[Task]:
        pending = self.pending_for_agent(agent)
        return pending[0] if pending else None

    def counts_by_status(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for t in self._tasks.values():
            out[t.status.value] = out.get(t.status.value, 0) + 1
        return out

    def progress(self) -> float:
        """Fraction of tasks DONE, 0.0-1.0. Returns 0 if there are no tasks yet."""
        if not self._tasks:
            return 0.0
        done = sum(1 for t in self._tasks.values() if t.status == TaskStatus.DONE)
        return done / len(self._tasks)

    def is_stuck(self) -> bool:
        """True if nothing is PENDING/IN_PROGRESS but not everything is DONE (deadlock)."""
        active = [t for t in self._tasks.values() if t.status in (TaskStatus.PENDING, TaskStatus.IN_PROGRESS)]
        done = [t for t in self._tasks.values() if t.status == TaskStatus.DONE]
        return not active and len(done) != len(self._tasks)
