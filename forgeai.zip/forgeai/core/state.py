"""
core/state.py

Holds cross-cutting state the UI needs to render: what each agent is
currently doing, and top-level project info. Updated by the orchestrator
as it dispatches tasks; read by ui/dashboard.py every frame.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from core.task import Task


class AgentStatus(str, Enum):
    IDLE = "idle"           # rendered ⚪
    WORKING = "working"     # rendered 🟡
    DONE = "done"           # rendered 🟢
    BLOCKED = "blocked"     # rendered 🔴


@dataclass
class AgentState:
    name: str
    status: AgentStatus = AgentStatus.IDLE
    current_task: Optional[Task] = None
    tasks_completed: int = 0
    tasks_failed: int = 0
    last_message: str = ""


@dataclass
class SystemState:
    project_name: str = "Untitled Project"
    project_goal: str = ""
    agents: dict[str, AgentState] = field(default_factory=dict)
    review_round: int = 0
    finished: bool = False

    def register(self, name: str) -> AgentState:
        state = self.agents.setdefault(name, AgentState(name=name))
        return state

    def set_working(self, name: str, task: Task) -> None:
        s = self.register(name)
        s.status = AgentStatus.WORKING
        s.current_task = task

    def set_idle(self, name: str, success: bool, message: str = "") -> None:
        s = self.register(name)
        s.status = AgentStatus.DONE if success else AgentStatus.BLOCKED
        if success:
            s.tasks_completed += 1
        else:
            s.tasks_failed += 1
        s.last_message = message
        s.current_task = None

    def overall_progress(self, queue) -> float:  # queue: core.queue.TaskQueue
        return queue.progress()
