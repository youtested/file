"""
core/workspace.py

Manages the on-disk area where worker agents will eventually write real
project files (workspace/active_project/ per the blueprint layout).
Phase 1-4: agents don't write files yet (they return canned strings), but
the manager is wired in now so Phase 5 only has to call write_file()
instead of also inventing a file-layout convention under time pressure.
"""

from __future__ import annotations

from pathlib import Path


class Workspace:
    def __init__(self, root: str | Path = "workspace/active_project") -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def _resolve(self, relative_path: str) -> Path:
        """Resolve a path inside the workspace, refusing to escape it."""
        target = (self.root / relative_path).resolve()
        if not str(target).startswith(str(self.root.resolve())):
            raise ValueError(f"Path escapes workspace: {relative_path}")
        return target

    def write_file(self, relative_path: str, content: str) -> Path:
        target = self._resolve(relative_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return target

    def read_file(self, relative_path: str) -> str:
        return self._resolve(relative_path).read_text(encoding="utf-8")

    def exists(self, relative_path: str) -> bool:
        return self._resolve(relative_path).exists()

    def list_files(self, relative_dir: str = ".") -> list[str]:
        base = self._resolve(relative_dir)
        if not base.exists():
            return []
        return sorted(
            str(p.relative_to(self.root)) for p in base.rglob("*") if p.is_file()
        )
