"""
core/project.py

SystemState (core/state.py) is runtime UI state -- agent statuses, current
tasks. Project is the persistent record of the project itself: goal,
acceptance criteria, and history across review rounds. Orchestrator loads
one at startup and saves it after every round so a crash can resume
mid-project (blueprint's "Project State" section).
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class ReviewRound:
    round_number: int
    passed: bool
    score: float
    report: dict[str, Any]
    timestamp: float = field(default_factory=time.time)


@dataclass
class Project:
    name: str
    goal: str
    acceptance_criteria: list[str] = field(default_factory=list)
    review_history: list[ReviewRound] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    completed: bool = False

    def record_round(self, round_number: int, passed: bool, score: float, report: dict[str, Any]) -> None:
        self.review_history.append(ReviewRound(round_number, passed, score, report))
        if passed:
            self.completed = True

    def latest_round(self) -> ReviewRound | None:
        return self.review_history[-1] if self.review_history else None

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Project":
        rounds = [ReviewRound(**r) for r in d.pop("review_history", [])]
        proj = cls(**d)
        proj.review_history = rounds
        return proj

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "Project | None":
        p = Path(path)
        if not p.exists():
            return None
        return cls.from_dict(json.loads(p.read_text(encoding="utf-8")))
