"""
core/agent_registry.py

Everything up through Phase 1 treated agents as fixed Python classes, one
file per agent. That's right for the agents with real custom logic
(Planner's breakdown, Reviewer's scoring) but wrong for "the user wants
to add a Mobile agent to the Build phase" -- nobody should have to write
and import a new .py file for that.

So: a registry of AgentDefinition records (persisted to
workspace/agents_registry.json) is now the source of truth for *which
agents exist and what phase they run in*. Built-in agents (planner,
reviewer, backend, ...) are seeded into the registry on first run with
builtin=True. Orchestrator resolves a definition to a runnable instance
via agents/factory.py: builtins map to their real class, anything else
becomes a agents.dynamic.DynamicAgent driven purely by its definition.

This is what lets the TUI's Add/Edit/Delete Agent screens work without
touching orchestrator.py or writing new source files per agent.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

from core.models import Phase

# Agents that are structural to the pipeline (planner plans, reviewer
# reviews) or ship as first-class code. They can be edited (description,
# working_message) but never deleted or moved out of their fixed role.
PROTECTED_AGENTS = {"planner", "reviewer"}

# name -> phase, description, working_message for every agent that
# shipped with a real class in agents/. Seeded into the registry once.
BUILTIN_DEFS: list[tuple[str, Optional[str], str, str]] = [
    ("planner",       None,               "Breaks the project goal into tasks and replans on review failure.", "Planning project..."),
    ("research",       "research",         "Looks up docs, breaking changes, and recommended architecture.",   "Researching..."),
    ("database",       "build",            "Designs schema, relationships, indexes, and migrations.",           "Designing schema..."),
    ("backend",         "build",            "Implements APIs, auth, business logic, and background workers.",   "Creating API..."),
    ("frontend",        "build",            "Implements pages, components, state, and layout.",                 "Building UI..."),
    ("testing",         "verify",           "Writes and runs unit/integration/e2e tests.",                      "Running tests..."),
    ("security",        "verify",           "Checks for secrets, injection, XSS/CSRF, auth issues.",            "Auditing for vulnerabilities..."),
    ("performance",     "verify",           "Checks memory, CPU, query, and bundle-size cost.",                  "Profiling performance..."),
    ("documentation",   "document",         "Writes README, API docs, and architecture notes.",                  "Writing documentation..."),
    ("reviewer",        None,               "Grades the round's output; never edits code.",                     "Review started..."),
    ("memory",          None,               "Stores/recalls project facts across runs. Invoked on demand.",     "Consulting memory..."),
    ("deployment",      None,               "Docker, CI/CD, cloud deploy. Invoked on demand.",                  "Preparing deployment..."),
    ("git",             None,               "Commit/branch/merge/diff/rollback. Invoked on demand.",            "Running version control operation..."),
]


@dataclass
class AgentDefinition:
    name: str
    phase: Optional[str]           # one of Phase.value, or None = on-demand (not in the review loop)
    description: str = ""
    working_message: str = "Working..."  # what DynamicAgent says while running a task
    builtin: bool = False
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def is_protected(self) -> bool:
        return self.name in PROTECTED_AGENTS

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "AgentDefinition":
        return cls(**d)


class AgentRegistry:
    def __init__(self, path: str | Path = "workspace/agents_registry.json") -> None:
        self.path = Path(path)
        self._defs: dict[str, AgentDefinition] = {}
        if self.path.exists():
            self._load()
        else:
            self._seed_builtins()
            self._save()

    # -- persistence --------------------------------------------------

    def _load(self) -> None:
        raw = json.loads(self.path.read_text(encoding="utf-8"))
        self._defs = {d["name"]: AgentDefinition.from_dict(d) for d in raw}

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps([d.to_dict() for d in self._defs.values()], indent=2),
            encoding="utf-8",
        )

    def _seed_builtins(self) -> None:
        for name, phase, desc, msg in BUILTIN_DEFS:
            self._defs[name] = AgentDefinition(
                name=name, phase=phase, description=desc,
                working_message=msg, builtin=True,
            )

    # -- CRUD -----------------------------------------------------------

    def list(self) -> list[AgentDefinition]:
        return sorted(self._defs.values(), key=lambda d: (d.phase or "zzz", d.name))

    def list_in_phase(self, phase: Phase) -> list[AgentDefinition]:
        return [d for d in self._defs.values() if d.phase == phase.value]

    def get(self, name: str) -> Optional[AgentDefinition]:
        return self._defs.get(name)

    def exists(self, name: str) -> bool:
        return name in self._defs

    def create(self, name: str, phase: Optional[str], description: str = "",
               working_message: str = "Working...") -> AgentDefinition:
        name = name.strip().lower().replace(" ", "_")
        if not name:
            raise ValueError("Agent name cannot be empty.")
        if self.exists(name):
            raise ValueError(f"An agent named '{name}' already exists.")
        if phase is not None and phase not in {p.value for p in Phase}:
            raise ValueError(f"Unknown phase '{phase}'.")
        definition = AgentDefinition(
            name=name, phase=phase, description=description,
            working_message=working_message or "Working...", builtin=False,
        )
        self._defs[name] = definition
        self._save()
        return definition

    def update(self, name: str, *, phase: Optional[str] = None, description: Optional[str] = None,
               working_message: Optional[str] = None) -> AgentDefinition:
        d = self._defs.get(name)
        if d is None:
            raise ValueError(f"No agent named '{name}'.")
        if d.is_protected() and phase is not None and phase != d.phase:
            raise ValueError(f"'{name}' is a protected agent and cannot change phase.")
        if phase is not None:
            if phase not in {p.value for p in Phase} and phase != "":
                raise ValueError(f"Unknown phase '{phase}'.")
            d.phase = phase or None
        if description is not None:
            d.description = description
        if working_message is not None:
            d.working_message = working_message or "Working..."
        d.updated_at = time.time()
        self._save()
        return d

    def delete(self, name: str) -> None:
        d = self._defs.get(name)
        if d is None:
            raise ValueError(f"No agent named '{name}'.")
        if d.is_protected():
            raise ValueError(f"'{name}' is a protected agent and cannot be deleted.")
        del self._defs[name]
        self._save()
