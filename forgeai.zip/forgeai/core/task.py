"""
core/task.py

Defines the Task object: the fundamental unit of work that flows through
the system. Planner creates Tasks, worker agents execute them, Reviewer
grades the output, and failed tasks get regenerated as new Tasks.
"""

from __future__ import annotations

import itertools
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


_id_counter = itertools.count(1)


class TaskStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    FAILED = "failed"
    BLOCKED = "blocked"


class TaskPriority(int, Enum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


@dataclass
class Task:
    """
    A single unit of work assigned to one agent.

    `id` is auto-generated and monotonically increasing so tasks can be
    sorted by creation order. `depends_on` holds ids of tasks that must
    reach DONE before this task is eligible to run (checked by the queue).
    """

    title: str
    description: str
    agent: str                                   # target agent name, e.g. "backend"
    priority: TaskPriority = TaskPriority.NORMAL
    status: TaskStatus = TaskStatus.PENDING
    depends_on: list[int] = field(default_factory=list)
    parent_id: Optional[int] = None               # set when spawned from a failed review
    result: Optional[str] = None                  # output produced by the agent
    error: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    id: int = field(default_factory=lambda: next(_id_counter))
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def start(self) -> None:
        self.status = TaskStatus.IN_PROGRESS
        self.updated_at = time.time()

    def complete(self, result: str) -> None:
        self.status = TaskStatus.DONE
        self.result = result
        self.updated_at = time.time()

    def fail(self, error: str) -> None:
        self.status = TaskStatus.FAILED
        self.error = error
        self.updated_at = time.time()

    def is_ready(self, done_ids: set[int]) -> bool:
        """True if every dependency has already completed."""
        return all(dep in done_ids for dep in self.depends_on)

    def spawn_followup(self, title: str, description: str, agent: str) -> "Task":
        """Create a new task representing rework, linked back to this one."""
        return Task(
            title=title,
            description=description,
            agent=agent,
            priority=TaskPriority.HIGH,
            parent_id=self.id,
        )

    def to_dict(self) -> dict[str, Any]:
        d = self.__dict__.copy()
        d["status"] = self.status.value
        d["priority"] = self.priority.value
        return d

    def __repr__(self) -> str:  # compact repr for logs/UI
        return f"Task(#{self.id} [{self.agent}] {self.status.value!r} {self.title!r})"
