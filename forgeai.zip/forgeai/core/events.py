"""
core/events.py

A minimal synchronous pub/sub event bus. Agents publish Events; the
dashboard, logger, and orchestrator subscribe. Kept dependency-free and
synchronous for now -- Phase 5 (real LLM calls) will likely move agent
execution onto asyncio, at which point this bus gains an async variant.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, DefaultDict, Optional
from collections import defaultdict


class EventType(str, Enum):
    AGENT_STATUS = "agent_status"       # agent changed state (idle/working/blocked)
    AGENT_MESSAGE = "agent_message"     # human-readable log line from an agent
    TASK_CREATED = "task_created"
    TASK_STARTED = "task_started"
    TASK_COMPLETED = "task_completed"
    TASK_FAILED = "task_failed"
    REVIEW_RESULT = "review_result"     # pass/fail from Reviewer
    SYSTEM = "system"                   # orchestrator-level events


@dataclass
class Event:
    type: EventType
    source: str                 # agent/component name that emitted it
    message: str
    data: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

    def __repr__(self) -> str:
        return f"[{self.source}] {self.type.value}: {self.message}"


Handler = Callable[[Event], None]


class EventBus:
    """
    Simple synchronous pub/sub. Subscribers can listen to a specific
    EventType or pass None to receive everything.
    """

    def __init__(self) -> None:
        self._subscribers: DefaultDict[Optional[EventType], list[Handler]] = defaultdict(list)
        self._history: list[Event] = []
        self._max_history = 2000

    def subscribe(self, handler: Handler, event_type: "EventType | None" = None) -> None:
        self._subscribers[event_type].append(handler)

    def publish(self, event: Event) -> None:
        self._history.append(event)
        if len(self._history) > self._max_history:
            self._history.pop(0)

        # Specific-type subscribers first, then wildcard (None) subscribers.
        for handler in self._subscribers.get(event.type, []):
            handler(event)
        for handler in self._subscribers.get(None, []):
            handler(event)

    def emit(self, type: EventType, source: str, message: str, **data: Any) -> None:
        self.publish(Event(type=type, source=source, message=message, data=data))

    def history(self, limit: int = 100) -> list[Event]:
        return self._history[-limit:]
