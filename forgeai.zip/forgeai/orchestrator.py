"""
orchestrator.py

Wires everything together and drives the loop:

    Planner -> Research -> Build (parallel) -> Verify (parallel)
            -> Document -> Reviewer -> PASS? --yes--> Finish
                                          '--no--> Planner (replan) -> targeted fix -> Reviewer -> ...

Which agents exist and which phase they belong to now comes from the
AgentRegistry (core/agent_registry.py), not a hardcoded dict -- so agents
added/edited/deleted through the TUI take effect on the very next run
without touching this file. agents/factory.py resolves each definition
to a runnable instance (builtin class or DynamicAgent).
"""

from __future__ import annotations

from agents.factory import build_agent
from agents.planner import PlannerAgent
from agents.reviewer import ReviewerAgent
from config import Config
from core.agent_registry import AgentRegistry
from core.events import EventBus, EventType
from core.models import PHASE_ORDER
from core.queue import TaskQueue
from core.scheduler import Scheduler
from core.state import SystemState
from core.task import Task, TaskPriority


class Orchestrator:
    def __init__(self, config: Config, registry: AgentRegistry | None = None) -> None:
        self.config = config
        self.bus = EventBus()
        self.state = SystemState(project_name=config.project_name, project_goal=config.project_goal)
        self.queue = TaskQueue()
        self.registry = registry or AgentRegistry(config.registry_path)
        self.scheduler = Scheduler(self.queue, self.registry)

        self.planner = PlannerAgent(self.bus, self.state, self.registry)
        self.reviewer = ReviewerAgent(self.bus, self.state, fail_rounds=config.simulated_fail_rounds)

        # Every phase-bound agent (research/build/verify/document), built
        # fresh from whatever the registry currently contains.
        self.workers = {
            d.name: build_agent(self.bus, self.state, d)
            for d in self.registry.list()
            if d.phase is not None
        }
        self._last_replan: Task | None = None

    def run(self) -> None:
        self.bus.emit(EventType.SYSTEM, "orchestrator", f"Starting project: {self.config.project_goal}")

        kickoff = Task(
            title="Break down project",
            description=self.config.project_goal,
            agent="planner",
            priority=TaskPriority.CRITICAL,
        )
        self.queue.add(kickoff)

        for round_num in range(1, self.config.max_review_rounds + 1):
            self.state.review_round = round_num

            if round_num == 1:
                self._run_planner_seed(kickoff)
                self._drain_phases()
            else:
                self._run_targeted_fix(self._last_replan)

            review_task = Task(
                title=f"Review round {round_num}",
                description="Grade the work produced this round.",
                agent="reviewer",
                priority=TaskPriority.HIGH,
            )
            self.queue.add(review_task)
            self.reviewer.execute(review_task)

            if review_task.metadata.get("passed"):
                self.state.finished = True
                self.bus.emit(EventType.SYSTEM, "orchestrator", "Project finished: review passed.")
                return

            replan_task = Task(
                title="Replan after failed review",
                description="",
                agent="planner",
                priority=TaskPriority.CRITICAL,
                metadata={
                    "kind": "replan",
                    "report": review_task.metadata.get("report", ""),
                    "target_agent": review_task.metadata.get("target_agent", "backend"),
                },
            )
            self.queue.add(replan_task)
            self.planner.execute(replan_task)
            for child in self.planner.new_children(replan_task):
                self.queue.add(child)
            self._last_replan = self.planner.new_children(replan_task)[0]

        self.bus.emit(EventType.SYSTEM, "orchestrator", "Max review rounds reached without passing.")

    def _run_planner_seed(self, seed_task: Task) -> None:
        self.planner.execute(seed_task)
        for child in self.planner.new_children(seed_task):
            self.queue.add(child)

    def _drain_phases(self) -> None:
        """Run every research/build/verify/document task, phase by phase."""
        self.scheduler.reset()
        for phase in PHASE_ORDER:
            if phase.value == "review":
                break  # reviewer runs separately, driven by run()
            self._drain_current_phase()
            if not self.scheduler.is_last_phase():
                self.scheduler.advance()

    def _drain_current_phase(self) -> None:
        progressed = True
        while progressed:
            progressed = False
            for task in self.scheduler.ready_tasks():
                if task.status.value != "pending":
                    continue
                agent = self.workers.get(task.agent)
                if agent is None:
                    continue
                agent.execute(task)
                progressed = True

    def _run_targeted_fix(self, followup: Task) -> None:
        """After a failed review, just rerun the one agent the report pointed at."""
        agent = self.workers.get(followup.agent)
        if agent is not None:
            agent.execute(followup)


if __name__ == "__main__":
    from config import config as default_config
    Orchestrator(default_config).run()
