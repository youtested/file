"""
agents/testing.py

Worker agent responsible for writing and running tests against whatever
the other workers have produced. Runs last in the default breakdown so
it has something to test.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.task import Task


class TestingAgent(BaseAgent):
    name = "testing"

    def run(self, task: Task) -> str:
        self.say("Running tests...")
        return f"Ran tests for: {task.title}"
