"""
agents/dynamic.py

Backs any AgentDefinition the user creates through the TUI (or by hand
in agents_registry.json) that isn't one of the built-in classes. Phase
1-4 behavior mirrors the built-ins: say the definition's working_message,
return a canned completion string. Phase 5 will give it the same real
LLM call the built-ins get, parameterized by definition.description as
the system prompt fragment -- so a user-created "Mobile" agent becomes
genuinely useful the moment Phase 5 lands, with no code changes here.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.agent_registry import AgentDefinition
from core.task import Task


class DynamicAgent(BaseAgent):
    def __init__(self, bus, state, definition: AgentDefinition) -> None:
        self.name = definition.name  # set before super().__init__ registers state under this name
        self.definition = definition
        super().__init__(bus, state)

    def run(self, task: Task) -> str:
        self.say(self.definition.working_message)
        return f"[{self.definition.name}] completed: {task.title}"
