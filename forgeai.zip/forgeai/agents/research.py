"""
agents/research.py

Worker agent for looking up docs/APIs/prior art before other agents
implement something. Not in the default breakdown yet; wired in once
the orchestrator supports on-demand task requests between agents.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.task import Task


class ResearchAgent(BaseAgent):
    name = "research"

    def run(self, task: Task) -> str:
        self.say("Researching...")
        return f"Completed research for: {task.title}"
