"""
agents/documentation.py

Worker agent responsible for README, API docs, architecture notes,
install/deploy guides, and inline comments. Runs after Verify, before
the Reviewer sees the round.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.task import Task


class DocumentationAgent(BaseAgent):
    name = "documentation"

    def run(self, task: Task) -> str:
        self.say("Writing documentation...")
        return f"Completed documentation for: {task.title}"
