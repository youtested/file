"""
agents/performance.py

Worker agent responsible for checking memory, CPU, network, DB query
efficiency, rendering cost, and bundle size. Runs in the Verify phase
alongside testing and security.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.task import Task


class PerformanceAgent(BaseAgent):
    name = "performance"

    def run(self, task: Task) -> str:
        self.say("Profiling performance...")
        return f"Completed performance check for: {task.title}"
