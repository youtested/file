"""
agents/reviewer.py

The Reviewer runs after every phase of a round completes. It never edits
code -- it only grades. It computes a weighted quality score across the
blueprint's categories (requirements, correctness, testing, performance,
security, documentation, code quality) and emits REVIEW_RESULT with the
full breakdown; the orchestrator uses passed/report to either finish the
project or hand the report back to the Planner.

Phase 1-4: grading is simulated (configurable failure count) so the
review loop and scoring math are exercised without an LLM. Phase 5
replaces `_grade_category()` with a real judgment against worker output.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.events import EventType
from core.models import QUALITY_WEIGHTS, QualityCategory
from core.task import Task

PASS_THRESHOLD = 0.90  # blueprint example passes at 98%; configurable minimum


class ReviewerAgent(BaseAgent):
    name = "reviewer"

    def __init__(self, bus, state, fail_rounds: int = 1) -> None:
        """
        `fail_rounds`: how many review rounds should fail before passing.
        Lets us exercise the retry loop deterministically without an LLM.
        """
        super().__init__(bus, state)
        self._fail_rounds = fail_rounds
        self._round = 0

    def run(self, task: Task) -> str:
        self.say("Review started...")
        self._round += 1
        simulate_failure = self._round <= self._fail_rounds

        scores, issues, target_agent = self._grade(simulate_failure)
        overall = sum(scores[cat] * weight for cat, weight in QUALITY_WEIGHTS.items())
        passed = overall >= PASS_THRESHOLD and not issues

        report = {
            "round": self._round,
            "scores": {cat.value: round(score, 2) for cat, score in scores.items()},
            "overall": round(overall, 4),
            "issues": issues,
        }

        self.bus.emit(
            EventType.REVIEW_RESULT,
            self.name,
            "PASS" if passed else "FAIL",
            passed=passed,
            report=report,
            target_agent=target_agent,
        )

        task.metadata["passed"] = passed
        task.metadata["report"] = self._format_report(report)
        task.metadata["quality_report"] = report
        task.metadata["target_agent"] = target_agent

        self.say("Review passed." if passed else "Review failed.")
        return self._format_report(report)

    def _grade(self, simulate_failure: bool) -> tuple[dict[QualityCategory, float], list[str], str]:
        """Returns (per-category scores 0-1, issue descriptions, agent to send failures to)."""
        scores = {cat: 1.0 for cat in QualityCategory}
        issues: list[str] = []
        target_agent = ""

        if simulate_failure:
            scores[QualityCategory.CORRECTNESS] = 0.6
            scores[QualityCategory.SECURITY] = 0.7
            issues.append("Backend API is missing input validation on the /login endpoint.")
            target_agent = "backend"

        return scores, issues, target_agent

    def _format_report(self, report: dict) -> str:
        lines = [f"Round {report['round']} \u2014 overall {report['overall'] * 100:.1f}%"]
        for cat, score in report["scores"].items():
            status = "PASS" if score >= PASS_THRESHOLD else "FAIL"
            lines.append(f"  {cat}: {status} ({score * 100:.0f}%)")
        for issue in report["issues"]:
            lines.append(f"  - {issue}")
        return "\n".join(lines)
