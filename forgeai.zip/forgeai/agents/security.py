"""
agents/security.py

Worker agent responsible for reviewing auth, input handling, and other
security-sensitive code paths. Distinct from ReviewerAgent: this agent
does defensive/security-specific analysis; Reviewer grades overall
correctness and completeness of the round's output.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.task import Task


class SecurityAgent(BaseAgent):
    name = "security"

    def run(self, task: Task) -> str:
        self.say("Auditing for vulnerabilities...")
        return f"Completed security review for: {task.title}"
