"""
agents/memory.py

Not a pipeline worker in the usual sense -- it doesn't take DEFAULT_BREAKDOWN
tasks. Instead it's queried by the orchestrator/other agents to store and
recall project facts (decisions made, files created, past review reports)
across runs. Phase 1: in-memory dict + JSON file persistence. A real
vector/embedding-backed version is a later-phase upgrade, not a rewrite.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agents.base import BaseAgent
from core.task import Task


class MemoryAgent(BaseAgent):
    name = "memory"

    def __init__(self, bus, state, path: str | Path = "workspace/memory.json") -> None:
        super().__init__(bus, state)
        self.path = Path(path)
        self._store: dict[str, Any] = self._load()

    def _load(self) -> dict[str, Any]:
        if self.path.exists():
            return json.loads(self.path.read_text(encoding="utf-8"))
        return {}

    def _persist(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self._store, indent=2), encoding="utf-8")

    def remember(self, key: str, value: Any) -> None:
        self._store[key] = value
        self._persist()

    def recall(self, key: str, default: Any = None) -> Any:
        return self._store.get(key, default)

    def run(self, task: Task) -> str:
        # Memory is invoked directly via remember()/recall() by other
        # components; run() exists so it still satisfies BaseAgent if the
        # orchestrator ever queues a task at it (e.g. "summarize project").
        self.say("Consulting memory...")
        return f"Memory has {len(self._store)} entries."
