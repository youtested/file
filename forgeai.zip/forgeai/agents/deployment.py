"""
agents/deployment.py

Handles Docker, CI/CD, and cloud deployment. Unlike the Build/Verify
agents, this isn't part of every review round -- it's invoked on demand
once a project has passed review (or explicitly requested), same pattern
as MemoryAgent. Not listed in core/models.py PHASE_AGENTS.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.task import Task


class DeploymentAgent(BaseAgent):
    name = "deployment"

    def run(self, task: Task) -> str:
        self.say("Preparing deployment...")
        return f"Completed deployment work for: {task.title}"
