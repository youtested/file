"""
agents/backend.py

Worker agent responsible for server-side/API code. Phase 1-4: emits a
simulated status message and a canned result so the pipeline is testable
without an LLM. Phase 5 replaces `run()`'s body with a real completion
call that writes actual files into workspace/.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.task import Task


class BackendAgent(BaseAgent):
    name = "backend"

    def run(self, task: Task) -> str:
        self.say("Creating API...")
        return f"Implemented backend work for: {task.title}"
