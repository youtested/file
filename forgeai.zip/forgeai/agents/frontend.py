"""
agents/frontend.py

Worker agent responsible for UI/client-side code. See backend.py for the
Phase 1-4 vs Phase 5 note; the same pattern applies to every worker agent.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.task import Task


class FrontendAgent(BaseAgent):
    name = "frontend"

    def run(self, task: Task) -> str:
        self.say("Building UI...")
        return f"Implemented frontend work for: {task.title}"
