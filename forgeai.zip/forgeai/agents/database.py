"""
agents/database.py

Worker agent responsible for schema design and migrations.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.task import Task


class DatabaseAgent(BaseAgent):
    name = "database"

    def run(self, task: Task) -> str:
        self.say("Designing schema...")
        return f"Implemented database work for: {task.title}"
