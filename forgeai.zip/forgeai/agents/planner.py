"""
agents/planner.py

The Planner is the entry point of the pipeline. It:
  1. Breaks the initial project goal into one task per agent, grouped by
     phase (Research -> Build -> Verify -> Document), with dependencies
     chained phase-to-phase so the scheduler gates them correctly.
  2. On review failure, reads the Reviewer's report and spawns a
     follow-up task targeted at whichever agent needs to redo work.

Task generation reads the *live* AgentRegistry rather than a fixed list,
so an agent added through the TUI mid-project is included in the very
next breakdown/replan without any code change here. In Phase 1-4 the
per-agent task text is templated from the agent's own description (see
DEFAULT_BREAKDOWN); Phase 5 replaces that templating with a real LLM
call that reads the project goal and decides what each agent should do.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.agent_registry import AgentRegistry
from core.models import PHASE_ORDER, Phase
from core.task import Task

# Phases the planner walks when building the graph, in order. REVIEW is
# excluded: the orchestrator runs the reviewer separately after DOCUMENT.
PLANNED_PHASES = [p for p in PHASE_ORDER if p != Phase.REVIEW]


class PlannerAgent(BaseAgent):
    name = "planner"

    def __init__(self, bus, state, registry: AgentRegistry) -> None:
        super().__init__(bus, state)
        self.registry = registry
        self._planned = False

    def run(self, task: Task) -> str:
        if task.metadata.get("kind") == "replan":
            return self._replan(task)
        return self._breakdown(task)

    def _breakdown(self, task: Task) -> str:
        self.say("Planning project...")
        created: list[Task] = []
        prior_phase_ids: list[int] = []

        for phase in PLANNED_PHASES:
            phase_defs = self.registry.list_in_phase(phase)
            phase_ids: list[int] = []
            for d in phase_defs:
                sub = Task(
                    title=f"{d.name.replace('_', ' ').title()}: {task.description[:40]}",
                    description=d.description or f"Do the {d.name} work for this project.",
                    agent=d.name,
                    parent_id=task.id,
                    depends_on=list(prior_phase_ids),
                )
                created.append(sub)
                phase_ids.append(sub.id)
            prior_phase_ids = phase_ids or prior_phase_ids  # empty phase doesn't break the chain

        task.metadata.setdefault("children", []).extend(created)
        self._planned = True
        phases_used = [p.value for p in PLANNED_PHASES if self.registry.list_in_phase(p)]
        return f"Created {len(created)} tasks across phases: {', '.join(phases_used)}"

    def _replan(self, task: Task) -> str:
        report = task.metadata.get("report", "")
        self.say(f"Revising plan based on review feedback: {report[:80]}")
        target_agent = task.metadata.get("target_agent", "backend")
        followup = task.spawn_followup(
            title="Address review feedback",
            description=report,
            agent=target_agent,
        )
        task.metadata.setdefault("children", []).append(followup)
        return f"Spawned follow-up task #{followup.id} for {target_agent}"

    def new_children(self, task: Task) -> list[Task]:
        """Helper for the orchestrator: pull out tasks this planner call created."""
        return task.metadata.get("children", [])
