"""
agents/ui_agent.py

Not a pipeline worker -- it doesn't take Build/Verify tasks. Per the
blueprint's "UI displays" responsibility, this agent owns turning raw
EventBus activity + SystemState into the snapshot shape ui/dashboard.py
renders (Phase 2), so the actual Textual/Rich app stays a thin render
layer with no business logic of its own.
"""

from __future__ import annotations

from typing import Any

from agents.base import BaseAgent
from core.task import Task


class UIAgent(BaseAgent):
    name = "ui"

    def snapshot(self) -> dict[str, Any]:
        """Build the dict ui/dashboard.py needs to render one frame."""
        return {
            "project_name": self.state.project_name,
            "project_goal": self.state.project_goal,
            "review_round": self.state.review_round,
            "finished": self.state.finished,
            "agents": {
                name: {
                    "status": s.status.value,
                    "current_task": s.current_task.title if s.current_task else None,
                    "tasks_completed": s.tasks_completed,
                    "tasks_failed": s.tasks_failed,
                    "last_message": s.last_message,
                }
                for name, s in self.state.agents.items()
            },
        }

    def run(self, task: Task) -> str:
        # UIAgent is queried directly via snapshot(); run() exists only to
        # satisfy BaseAgent in case the orchestrator ever queues it a task.
        self.say("Refreshing dashboard snapshot...")
        return "Snapshot refreshed."
