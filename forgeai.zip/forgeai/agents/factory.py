"""
agents/factory.py

Single place that knows how to turn an AgentDefinition into a runnable
agent instance. Builtins get their real class (Planner's replanning
logic, Reviewer's scoring, etc. all live on); anything the user added
through the registry gets DynamicAgent. Orchestrator and the TUI both
go through here so neither has to special-case "is this a builtin?".
"""

from __future__ import annotations

from agents.backend import BackendAgent
from agents.base import BaseAgent
from agents.database import DatabaseAgent
from agents.deployment import DeploymentAgent
from agents.documentation import DocumentationAgent
from agents.dynamic import DynamicAgent
from agents.frontend import FrontendAgent
from agents.git_agent import GitAgent
from agents.memory import MemoryAgent
from agents.performance import PerformanceAgent
from agents.planner import PlannerAgent
from agents.research import ResearchAgent
from agents.reviewer import ReviewerAgent
from agents.security import SecurityAgent
from agents.testing import TestingAgent
from core.agent_registry import AgentDefinition

BUILTIN_CLASSES: dict[str, type[BaseAgent]] = {
    "planner": PlannerAgent,
    "reviewer": ReviewerAgent,
    "research": ResearchAgent,
    "database": DatabaseAgent,
    "backend": BackendAgent,
    "frontend": FrontendAgent,
    "testing": TestingAgent,
    "security": SecurityAgent,
    "performance": PerformanceAgent,
    "documentation": DocumentationAgent,
    "memory": MemoryAgent,
    "deployment": DeploymentAgent,
    "git": GitAgent,
}


def build_agent(bus, state, definition: AgentDefinition) -> BaseAgent:
    cls = BUILTIN_CLASSES.get(definition.name) if definition.builtin else None
    if cls is not None:
        return cls(bus, state)
    return DynamicAgent(bus, state, definition)
