"""
agents/base.py

BaseAgent defines the contract every specialized agent (planner, backend,
reviewer, ...) implements. In Phase 1-4, `run(task)` returns a canned
string so the pipeline is testable end-to-end without an LLM. Phase 5
replaces the body of `run()` with a real completion call, but the
interface below does not change -- that's the point of isolating it here.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod

from core.events import EventBus, EventType
from core.state import SystemState
from core.task import Task


class BaseAgent(ABC):
    name: str = "base"

    def __init__(self, bus: EventBus, state: SystemState) -> None:
        self.bus = bus
        self.state = state
        self.state.register(self.name)

    def say(self, message: str) -> None:
        """Emit a human-readable status line, e.g. 'Planning project...'."""
        self.bus.emit(EventType.AGENT_MESSAGE, self.name, message)

    def execute(self, task: Task) -> Task:
        """
        Wraps run() with bookkeeping common to every agent: state
        transitions, timing, event emission, and error containment so one
        agent's exception can't crash the orchestrator loop.
        """
        self.state.set_working(self.name, task)
        task.start()
        self.bus.emit(EventType.TASK_STARTED, self.name, task.title, task_id=task.id)

        start = time.time()
        try:
            result = self.run(task)
            task.complete(result)
            elapsed = time.time() - start
            self.say(f"Completed '{task.title}' in {elapsed:.1f}s")
            self.state.set_idle(self.name, success=True, message=task.title)
            self.bus.emit(EventType.TASK_COMPLETED, self.name, task.title, task_id=task.id)
        except Exception as exc:  # noqa: BLE001 - deliberately broad, isolates agent failures
            task.fail(str(exc))
            self.say(f"Failed '{task.title}': {exc}")
            self.state.set_idle(self.name, success=False, message=str(exc))
            self.bus.emit(EventType.TASK_FAILED, self.name, task.title, task_id=task.id, error=str(exc))

        return task

    @abstractmethod
    def run(self, task: Task) -> str:
        """Perform the actual work for `task` and return a result string."""
        raise NotImplementedError
