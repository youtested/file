"""
agents/git_agent.py

Handles commit, branch, merge, diff, history, and rollback. Named
git_agent (not git.py) to avoid shadowing a real `git` import anywhere
in the codebase or tooling. Invoked on demand, not part of PHASE_AGENTS --
same reasoning as deployment.py.
"""

from __future__ import annotations

from agents.base import BaseAgent
from core.task import Task


class GitAgent(BaseAgent):
    name = "git"

    def run(self, task: Task) -> str:
        self.say("Running version control operation...")
        return f"Completed git operation for: {task.title}"
