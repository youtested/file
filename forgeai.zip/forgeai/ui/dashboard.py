"""
ui/dashboard.py

The main screen: project status, an agent table (select + Enter to
inspect one agent, a/e/d to add/edit/delete), and a live combined-log
tail. Business logic stays in Orchestrator/AgentRegistry; this screen
only renders SystemState/EventBus and dispatches user actions to them.

Threading model: Orchestrator.run() is a long blocking call, so it's
launched via App.run_worker(thread=True). The EventBus callback runs on
that worker thread; it hands off to the Textual event loop with
App.call_from_thread() before touching any widget, since Textual widgets
aren't thread-safe to mutate directly from a background thread.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import DataTable, ProgressBar, Static

from core.events import Event
from ui.agent_screen import AgentDetailScreen
from ui.footer import AppFooter
from ui.header import AppHeader
from ui.log_panel import LogPanel
from ui.notifications import notify_app
from ui.widgets import AGENT_TABLE_COLUMNS, agent_row


class DashboardScreen(Screen):
    BINDINGS = [
        Binding("n", "new_project", "New Project"),
        Binding("a", "add_agent", "Add Agent"),
        Binding("e", "edit_agent", "Edit"),
        Binding("d", "delete_agent", "Delete"),
        Binding("enter", "inspect_agent", "Inspect"),
        Binding("q", "app.quit", "Quit"),
    ]

    def compose(self) -> ComposeResult:
        yield AppHeader()
        with Vertical(id="dashboard-body"):
            yield Static(id="project-info")
            yield ProgressBar(id="project-progress", show_eta=False)
            with Horizontal(id="dashboard-main"):
                yield DataTable(id="agent-table")
                yield LogPanel(id="combined-log")
        yield AppFooter()

    def on_mount(self) -> None:
        table = self.query_one("#agent-table", DataTable)
        table.cursor_type = "row"
        table.add_columns(*AGENT_TABLE_COLUMNS)
        self.refresh_agent_table()
        self.refresh_project_info()
        self.set_interval(1.0, self.refresh_project_info)  # progress bar / header stay current even between events

    # -- rendering --------------------------------------------------

    def refresh_agent_table(self) -> None:
        app = self.app  # type: ignore[attr-defined]
        table = self.query_one("#agent-table", DataTable)
        selected_key = self._selected_agent_name()
        table.clear()
        agent_states = app.orchestrator.state.agents if app.orchestrator else {}
        for definition in app.registry.list():
            state = agent_states.get(definition.name)
            table.add_row(*agent_row(definition, state), key=definition.name)
        if selected_key is not None:
            self._select_agent_row(selected_key)

    def refresh_project_info(self) -> None:
        app = self.app  # type: ignore[attr-defined]
        info = self.query_one("#project-info", Static)
        bar = self.query_one("#project-progress", ProgressBar)

        if app.orchestrator is None:
            info.update("[b]ForgeAI[/b]  \u2014  no project running. Press [b]N[/b] to start one.")
            bar.update(total=100, progress=0)
            return

        state = app.orchestrator.state
        queue = app.orchestrator.queue
        progress_pct = queue.progress() * 100
        status = "FINISHED" if state.finished else f"round {state.review_round}"
        info.update(
            f"[b]{state.project_name}[/b]  \u2014  {state.project_goal}\n"
            f"Status: {status}   Progress: {progress_pct:.0f}%"
        )
        bar.update(total=100, progress=progress_pct)

    def _selected_agent_name(self) -> str | None:
        table = self.query_one("#agent-table", DataTable)
        if table.row_count == 0 or table.cursor_row is None:
            return None
        try:
            row_key, _ = table.coordinate_to_cell_key(table.cursor_coordinate)
            return str(row_key.value) if row_key is not None else None
        except Exception:
            return None

    def _select_agent_row(self, name: str) -> None:
        table = self.query_one("#agent-table", DataTable)
        try:
            table.move_cursor(row=table.get_row_index(name))
        except Exception:
            pass

    # -- live event handling -----------------------------------------

    def handle_event(self, event: Event) -> None:
        """Called by ForgeAIApp (via call_from_thread) whenever the orchestrator's
        EventBus emits something and this screen is the active one."""
        self.refresh_agent_table()
        self.refresh_project_info()
        log_panel = self.query_one("#combined-log", LogPanel)
        log_panel.append_line(repr(event))
        notify_app(self.app, event)

    # -- actions ------------------------------------------------------

    def action_new_project(self) -> None:
        from ui.project_form import ProjectFormScreen

        app = self.app  # type: ignore[attr-defined]

        def handle_result(goal: str | None) -> None:
            if goal:
                app.start_project(goal)
                self.refresh_project_info()
                self.refresh_agent_table()

        self.app.push_screen(ProjectFormScreen(default_goal=app.config.project_goal), handle_result)

    def action_add_agent(self) -> None:
        from ui.agent_form import AgentFormScreen

        app = self.app  # type: ignore[attr-defined]

        def handle_result(result) -> None:
            if result:
                app.notify(f"Added agent '{result.name}'.")
                app.rebuild_workers_if_idle()
                self.refresh_agent_table()

        self.app.push_screen(AgentFormScreen(registry=app.registry), handle_result)

    def action_edit_agent(self) -> None:
        name = self._selected_agent_name()
        if name is None:
            return
        from ui.agent_form import AgentFormScreen

        app = self.app  # type: ignore[attr-defined]
        definition = app.registry.get(name)
        if definition is None:
            return

        def handle_result(result) -> None:
            if result:
                app.notify(f"Updated agent '{name}'.")
                app.rebuild_workers_if_idle()
                self.refresh_agent_table()

        self.app.push_screen(AgentFormScreen(registry=app.registry, existing=definition), handle_result)

    def action_delete_agent(self) -> None:
        name = self._selected_agent_name()
        if name is None:
            return
        from ui.confirm import ConfirmScreen

        app = self.app  # type: ignore[attr-defined]

        def handle_result(confirmed: bool) -> None:
            if not confirmed:
                return
            try:
                app.registry.delete(name)
                app.notify(f"Deleted agent '{name}'.")
                app.rebuild_workers_if_idle()
                self.refresh_agent_table()
            except ValueError as exc:
                app.notify(str(exc), severity="error")

        self.app.push_screen(ConfirmScreen(f"Delete agent '{name}'? This cannot be undone."), handle_result)

    def action_inspect_agent(self) -> None:
        name = self._selected_agent_name()
        if name is None:
            return
        self.app.push_screen(AgentDetailScreen(name))
