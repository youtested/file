"""
ui/project_form.py

Small modal collecting the project goal before starting a run. Dismisses
with the goal string, or None on cancel.
"""

from __future__ import annotations

from typing import Optional

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, Static


class ProjectFormScreen(ModalScreen[Optional[str]]):
    def __init__(self, default_goal: str = "") -> None:
        super().__init__()
        self.default_goal = default_goal

    def compose(self) -> ComposeResult:
        with Vertical(id="project-form"):
            yield Static("New project", id="project-form-title")
            yield Label("Project goal")
            yield Input(value=self.default_goal, placeholder="e.g. Build a Discord clone", id="field-goal")
            with Horizontal(id="project-form-buttons"):
                yield Button("Start", id="start", variant="primary")
                yield Button("Cancel", id="cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel":
            self.dismiss(None)
            return
        goal = self.query_one("#field-goal", Input).value.strip()
        self.dismiss(goal or None)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        goal = event.value.strip()
        self.dismiss(goal or None)
