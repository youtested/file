"""
ui/notifications.py

Small helper so the mapping from EventType -> toast severity lives in
one place instead of being duplicated across dashboard.py and any future
screen that wants to surface bus events as toasts.
"""

from __future__ import annotations

from core.events import Event, EventType

SEVERITY = {
    EventType.TASK_FAILED: "error",
    EventType.REVIEW_RESULT: "warning",   # overridden to "information" on pass by caller
    EventType.SYSTEM: "information",
    EventType.TASK_COMPLETED: "information",
}


def severity_for(event: Event) -> str:
    if event.type == EventType.REVIEW_RESULT:
        return "information" if event.data.get("passed") else "warning"
    return SEVERITY.get(event.type, "information")


def notify_app(app, event: Event) -> None:
    """Fire a toast for events worth surfacing; silently ignore chatter
    (agent_message/task_started) that would otherwise spam every second."""
    if event.type not in (EventType.REVIEW_RESULT, EventType.TASK_FAILED, EventType.SYSTEM):
        return
    app.notify(event.message, severity=severity_for(event))
