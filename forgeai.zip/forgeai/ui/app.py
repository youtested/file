"""
ui/app.py

Entry point for the TUI (`python main.py --tui`). Owns the AgentRegistry
and, once a project is started, the Orchestrator. Runs the orchestrator
in a background thread (Orchestrator.run() blocks) and bridges its
EventBus into the Textual event loop via call_from_thread so widgets are
only ever touched from the main thread.
"""

from __future__ import annotations

from textual.app import App

from config import Config, config as default_config
from core.agent_registry import AgentRegistry
from core.events import Event
from core.logger import Logger
from orchestrator import Orchestrator
from ui.dashboard import DashboardScreen

CSS_PATH = "ui/app.tcss"


class ForgeAIApp(App):
    CSS_PATH = CSS_PATH
    TITLE = "ForgeAI"
    SCREENS = {"dashboard": DashboardScreen}

    def __init__(self, config: Config | None = None) -> None:
        super().__init__()
        self.config = config or default_config
        self.registry = AgentRegistry(self.config.registry_path)
        self.orchestrator: Orchestrator | None = None

    def on_mount(self) -> None:
        self.push_screen("dashboard")

    # -- project lifecycle --------------------------------------------

    def start_project(self, goal: str) -> None:
        """(Re)creates the orchestrator against the current registry and
        launches its blocking run() on a worker thread."""
        self.config.project_goal = goal
        self.orchestrator = Orchestrator(self.config, registry=self.registry)
        self.orchestrator.bus.subscribe(self._on_bus_event)      # UI updates
        Logger(self.orchestrator.bus, log_dir=self.config.log_dir)  # workspace/logs/<agent>.log
        self.run_worker(self.orchestrator.run, thread=True, exclusive=True, group="project")

    def rebuild_workers_if_idle(self) -> None:
        """
        Agent add/edit/delete only takes effect for the *next* orchestrator
        run (mutating self.workers mid-round would race with the worker
        thread). If no project is currently running, there's nothing to
        protect, so nothing else needs to happen here -- the next
        start_project() call already reads the live registry.
        """
        if self.orchestrator is not None and not self.orchestrator.state.finished:
            self.notify(
                "Agent roster updated. Changes apply on the next project run.",
                severity="information",
            )

    # -- thread bridge --------------------------------------------------

    def _on_bus_event(self, event: Event) -> None:
        """Runs on the orchestrator's worker thread. Hands off to the
        Textual (main) thread before touching any widget."""
        self.call_from_thread(self._dispatch_event, event)

    def _dispatch_event(self, event: Event) -> None:
        screen = self.screen
        handler = getattr(screen, "handle_event", None)
        if handler is not None:
            handler(event)


def run() -> None:
    ForgeAIApp().run()


if __name__ == "__main__":
    run()
