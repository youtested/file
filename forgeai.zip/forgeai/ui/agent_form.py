"""
ui/agent_form.py

Modal used for both "Add Agent" and "Edit Agent". Same layout either way;
when `existing` is passed the name field is locked (renaming isn't
supported -- tasks already in flight reference agents by name) and the
fields are pre-filled. Dismisses with the resulting AgentDefinition on
Save, or None on Cancel, so callers can just check truthiness.
"""

from __future__ import annotations

from typing import Optional

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, Select, Static

from core.agent_registry import AgentDefinition, AgentRegistry
from core.models import Phase

PHASE_OPTIONS: list[tuple[str, str]] = [(p.value.title(), p.value) for p in Phase if p != Phase.REVIEW]
PHASE_OPTIONS.append(("On-demand (not in review loop)", ""))


class AgentFormScreen(ModalScreen[Optional[AgentDefinition]]):
    def __init__(self, registry: AgentRegistry, existing: AgentDefinition | None = None) -> None:
        super().__init__()
        self.registry = registry
        self.existing = existing

    def compose(self) -> ComposeResult:
        is_edit = self.existing is not None
        title = f"Edit agent: {self.existing.name}" if is_edit else "Add new agent"

        with Vertical(id="agent-form"):
            yield Static(title, id="agent-form-title")

            yield Label("Name")
            yield Input(
                value=self.existing.name if is_edit else "",
                placeholder="e.g. mobile",
                id="field-name",
                disabled=is_edit,
            )

            yield Label("Phase")
            yield Select(
                PHASE_OPTIONS,
                value=(self.existing.phase or "") if is_edit else "build",
                id="field-phase",
                disabled=bool(is_edit and self.existing.is_protected()),
            )

            yield Label("Description (what this agent is responsible for)")
            yield Input(
                value=self.existing.description if is_edit else "",
                placeholder="e.g. Implements iOS/Android client screens.",
                id="field-description",
            )

            yield Label("Working message (shown while it's running a task)")
            yield Input(
                value=self.existing.working_message if is_edit else "Working...",
                placeholder="e.g. Building mobile screens...",
                id="field-message",
            )

            yield Static("", id="agent-form-error")

            with Horizontal(id="agent-form-buttons"):
                yield Button("Save", id="save", variant="primary")
                yield Button("Cancel", id="cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel":
            self.dismiss(None)
            return
        if event.button.id == "save":
            self._save()

    def _save(self) -> None:
        name = self.query_one("#field-name", Input).value.strip()
        phase_value = self.query_one("#field-phase", Select).value
        phase = phase_value or None
        description = self.query_one("#field-description", Input).value.strip()
        message = self.query_one("#field-message", Input).value.strip() or "Working..."
        error = self.query_one("#agent-form-error", Static)

        try:
            if self.existing is not None:
                result = self.registry.update(
                    self.existing.name, phase=phase, description=description, working_message=message,
                )
            else:
                result = self.registry.create(
                    name, phase=phase, description=description, working_message=message,
                )
        except ValueError as exc:
            error.update(f"[red]{exc}[/red]")
            return

        self.dismiss(result)
