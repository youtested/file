"""
ui/widgets.py

Small, reusable pieces shared by dashboard.py and agent_screen.py. Kept
free of any screen/app logic so they're easy to reuse if a second view
(e.g. a future Textual-web dashboard) is added later.
"""

from __future__ import annotations

from core.agent_registry import AgentDefinition
from core.state import AgentState, AgentStatus

STATUS_ICON: dict[AgentStatus, str] = {
    AgentStatus.IDLE: "\u26aa",     # ⚪
    AgentStatus.WORKING: "\U0001f7e1",  # 🟡
    AgentStatus.DONE: "\U0001f7e2",     # 🟢
    AgentStatus.BLOCKED: "\U0001f534",  # 🔴
}

PHASE_LABEL: dict[str | None, str] = {
    "research": "Research",
    "build": "Build",
    "verify": "Verify",
    "document": "Document",
    None: "On-demand",
}


def status_icon(status: AgentStatus) -> str:
    return STATUS_ICON.get(status, "\u26aa")


def phase_label(phase: str | None) -> str:
    return PHASE_LABEL.get(phase, phase or "On-demand")


def agent_row(definition: AgentDefinition, state: AgentState | None) -> tuple[str, ...]:
    """Column values for one row of the dashboard's agent table."""
    status = state.status if state else AgentStatus.IDLE
    current = state.current_task.title if (state and state.current_task) else "-"
    completed = str(state.tasks_completed) if state else "0"
    failed = str(state.tasks_failed) if state else "0"
    origin = "builtin" if definition.builtin else "custom"
    return (
        status_icon(status),
        definition.name,
        phase_label(definition.phase),
        origin,
        current,
        completed,
        failed,
    )


AGENT_TABLE_COLUMNS = ("", "Agent", "Phase", "Type", "Current Task", "Done", "Failed")
