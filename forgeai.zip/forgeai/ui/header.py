"""
ui/header.py

Thin subclass of Textual's built-in Header. Kept as its own module (per
the project's file layout) so branding/clock/status customization has an
obvious home later, without screens needing to import textual.widgets
directly for it.
"""

from __future__ import annotations

from textual.widgets import Header as _Header


class AppHeader(_Header):
    def __init__(self, **kwargs) -> None:
        kwargs.setdefault("show_clock", True)
        super().__init__(**kwargs)
