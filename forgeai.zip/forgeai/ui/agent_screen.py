"""
ui/agent_screen.py

Per-agent detail view, matching the blueprint's "Clicking an Agent"
screen: status, current task, and a live tail of that agent's own log
file (logs never mix between agents). Also exposes Edit/Delete directly
so the user doesn't have to go back to the dashboard to manage the agent
they're already looking at.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import Screen
from textual.widgets import Static

from ui.footer import AppFooter
from ui.header import AppHeader
from ui.log_panel import LogPanel
from ui.widgets import phase_label, status_icon


class AgentDetailScreen(Screen):
    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back"),
        Binding("e", "edit_agent", "Edit"),
        Binding("d", "delete_agent", "Delete"),
        Binding("r", "refresh_view", "Refresh"),
    ]

    def __init__(self, agent_name: str) -> None:
        super().__init__()
        self.agent_name = agent_name

    def compose(self) -> ComposeResult:
        yield AppHeader()
        with Vertical(id="agent-detail-body"):
            yield Static(id="agent-summary")
            yield LogPanel(id="agent-log")
        yield AppFooter()

    def on_mount(self) -> None:
        self.action_refresh_view()

    def handle_event(self, event) -> None:  # noqa: ANN001 - core.events.Event, avoided import cycle
        """Called by ForgeAIApp (via call_from_thread) while this screen is active."""
        self.action_refresh_view()

    def action_refresh_view(self) -> None:
        app = self.app  # type: ignore[attr-defined]
        definition = app.registry.get(self.agent_name)
        state = app.orchestrator.state.agents.get(self.agent_name) if app.orchestrator else None

        summary = self.query_one("#agent-summary", Static)
        if definition is None:
            summary.update(f"No such agent: {self.agent_name}")
            return

        icon = status_icon(state.status) if state else "\u26aa"
        status_text = state.status.value if state else "idle"
        current = state.current_task.title if (state and state.current_task) else "-"
        completed = state.tasks_completed if state else 0
        failed = state.tasks_failed if state else 0
        last_msg = state.last_message if state else ""

        summary.update(
            f"[b]{definition.name}[/b]  {icon} {status_text}\n"
            f"Phase: {phase_label(definition.phase)}   "
            f"Type: {'builtin' if definition.builtin else 'custom'}\n"
            f"Description: {definition.description or '-'}\n"
            f"Current task: {current}\n"
            f"Completed: {completed}   Failed: {failed}\n"
            f"Last message: {last_msg}"
        )

        log_panel = self.query_one("#agent-log", LogPanel)
        log_path = f"{app.config.log_dir}/{self.agent_name}.log"
        log_panel.load_tail(log_path)

    def action_edit_agent(self) -> None:
        from ui.agent_form import AgentFormScreen

        app = self.app  # type: ignore[attr-defined]
        definition = app.registry.get(self.agent_name)
        if definition is None:
            return

        def handle_result(result) -> None:
            if result:
                app.notify(f"Updated agent '{self.agent_name}'.")
                self.action_refresh_view()

        self.app.push_screen(AgentFormScreen(registry=app.registry, existing=definition), handle_result)

    def action_delete_agent(self) -> None:
        from ui.confirm import ConfirmScreen

        app = self.app  # type: ignore[attr-defined]

        def handle_result(confirmed: bool) -> None:
            if not confirmed:
                return
            try:
                app.registry.delete(self.agent_name)
                app.notify(f"Deleted agent '{self.agent_name}'.")
                self.app.pop_screen()
            except ValueError as exc:
                app.notify(str(exc), severity="error")

        self.app.push_screen(
            ConfirmScreen(f"Delete agent '{self.agent_name}'? This cannot be undone."),
            handle_result,
        )
