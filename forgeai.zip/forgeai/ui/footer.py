"""
ui/footer.py

Thin subclass of Textual's built-in Footer. See header.py for why this
wraps rather than uses the built-in directly.
"""

from __future__ import annotations

from textual.widgets import Footer as _Footer


class AppFooter(_Footer):
    pass
