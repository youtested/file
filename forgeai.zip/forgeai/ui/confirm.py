"""
ui/confirm.py

Generic confirm/cancel modal. Dismisses with True/False. Kept
content-agnostic (just a message string) so it's reusable for delete
confirmations anywhere in the app, not just agents.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Static


class ConfirmScreen(ModalScreen[bool]):
    def __init__(self, message: str, confirm_label: str = "Delete", cancel_label: str = "Cancel") -> None:
        super().__init__()
        self.message = message
        self.confirm_label = confirm_label
        self.cancel_label = cancel_label

    def compose(self) -> ComposeResult:
        with Vertical(id="confirm-box"):
            yield Static(self.message, id="confirm-message")
            with Horizontal(id="confirm-buttons"):
                yield Button(self.confirm_label, id="confirm", variant="error")
                yield Button(self.cancel_label, id="cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "confirm")
