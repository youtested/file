"""
ui/log_panel.py

A thin Log subclass that knows how to load the tail of a log file from
workspace/logs/. Used both by the dashboard (combined.log) and the
agent detail screen (<agent>.log). Appending is push-based: callers
call append_line() as new events arrive rather than re-reading the file
every frame, so it stays cheap even with a fast-moving event bus.
"""

from __future__ import annotations

from pathlib import Path

from textual.widgets import Log


class LogPanel(Log):
    def __init__(self, **kwargs) -> None:
        super().__init__(max_lines=2000, **kwargs)

    def load_tail(self, path: str | Path, n: int = 200) -> None:
        self.clear()
        p = Path(path)
        if not p.exists():
            return
        lines = p.read_text(encoding="utf-8").splitlines()[-n:]
        for line in lines:
            self.write_line(line)

    def append_line(self, line: str) -> None:
        self.write_line(line)
