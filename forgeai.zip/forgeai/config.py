"""
config.py

Central place for settings. Phase 1-4: mostly static values controlling
the simulated pipeline. Phase 5 adds LLM provider/model/key settings,
read from environment variables (never hardcoded).
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class Config:
    project_name: str = "Untitled Project"
    project_goal: str = "Build a Discord clone"

    workspace_dir: str = "workspace"
    log_dir: str = "workspace/logs"
    memory_path: str = "workspace/memory.json"
    registry_path: str = "workspace/agents_registry.json"

    # Ordered so the dashboard's agent panel has a stable layout.
    agent_order: list[str] = field(default_factory=lambda: [
        "planner", "research", "database", "backend", "frontend",
        "testing", "security", "performance", "documentation", "reviewer",
    ])

    # Review loop
    max_review_rounds: int = 5
    simulated_fail_rounds: int = 1   # how many rounds ReviewerAgent fails before passing (Phase 1-4 only)

    # UI
    dashboard_refresh_seconds: float = 0.5

    # Phase 5: LLM settings, read from env so no secrets live in source.
    llm_provider: str = os.environ.get("AI_COMPANY_LLM_PROVIDER", "anthropic")
    llm_model: str = os.environ.get("AI_COMPANY_LLM_MODEL", "claude-sonnet-4-6")
    llm_api_key: str = os.environ.get("ANTHROPIC_API_KEY", "")
    llm_enabled: bool = bool(os.environ.get("ANTHROPIC_API_KEY", ""))


config = Config()
