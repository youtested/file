"""
main.py

Two entry points:
  python main.py --tui                 -> launches the Textual dashboard (Phase 2)
  python main.py "Build a Discord clone" -> headless run, prints every event to stdout

Headless mode still exists because it's the fastest way to smoke-test
orchestrator/registry changes without a real terminal (see the dev notes
in orchestrator.py) -- the TUI is a thin render layer on top of the same
Orchestrator, not a replacement code path.
"""

from __future__ import annotations

import sys

from config import config
from core.events import Event
from core.logger import Logger
from orchestrator import Orchestrator


def print_event(event: Event) -> None:
    print(repr(event))


def run_headless() -> None:
    args = [a for a in sys.argv[1:] if a != "--tui"]
    if args:
        config.project_goal = " ".join(args)

    orch = Orchestrator(config)
    orch.bus.subscribe(print_event)           # console output
    Logger(orch.bus, log_dir=config.log_dir)  # persists workspace/logs/<agent>.log + combined.log

    orch.run()

    print("\n--- Final task queue ---")
    for task in orch.queue.all():
        print(f"  {task!r}")
    print(f"\nProgress: {orch.queue.progress() * 100:.0f}%  Finished: {orch.state.finished}")


def run_tui() -> None:
    from ui.app import ForgeAIApp
    ForgeAIApp(config).run()


def main() -> None:
    if "--tui" in sys.argv:
        run_tui()
    else:
        run_headless()


if __name__ == "__main__":
    main()
